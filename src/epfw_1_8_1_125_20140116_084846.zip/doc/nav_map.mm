<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1312185634104" ID="ID_1933591793" MODIFIED="1312697798138" TEXT="Home">
<node CREATED="1312186752953" ID="ID_41996585" MODIFIED="1339908192685" POSITION="right" TEXT="">
<cloud/>
<node CREATED="1312185738905" ID="ID_803601892" LINK="http://localhost:3000/portal/home" MODIFIED="1312697798138" TEXT="Home"/>
<node CREATED="1312185837175" FOLDED="true" ID="ID_1369104956" LINK="http://localhost:3000/portal/wikis" MODIFIED="1339312497273" TEXT="Wikis">
<icon BUILTIN="button_ok"/>
<node CREATED="1312187029866" ID="ID_1284940203" LINK="http://localhost:3000/sites/description?id=2" MODIFIED="1312697798139" TEXT="Templates">
<icon BUILTIN="button_ok"/>
<node CREATED="1312187061498" ID="ID_848698351" LINK="http://localhost:3000/development_wikis/templates/new/guidances/supportingmaterials/supporting_material_template_D3F13112.html?nodeId=428c1db8" MODIFIED="1312697798139" TEXT="Supporting material template">
<icon BUILTIN="button_ok"/>
<node CREATED="1312254155060" ID="ID_625913868" LINK="http://localhost:3000/development_wikis/templates/new/guidances/supportingmaterials/supporting_material_template_D3F13112.html" MODIFIED="1312697798140" TEXT="View">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312254193931" ID="ID_1888523734" LINK="http://localhost:3000/templates/35/discussion" MODIFIED="1312697798140" TEXT="Discussion">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312200182897" ID="ID_1070789323" LINK="http://localhost:3000/pages/edit?id=35&amp;site_folder=templates" MODIFIED="1312697798140" TEXT="Edit">
<icon BUILTIN="button_ok"/>
<node CREATED="1312371248261" ID="ID_33755515" MODIFIED="1312697798140" TEXT="Checkout">
<icon BUILTIN="button_ok"/>
<node CREATED="1312371263516" ID="ID_1310816096" MODIFIED="1312697798140" TEXT="Save">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312371267666" ID="ID_1670019802" MODIFIED="1312697798141" TEXT="Checkin">
<icon BUILTIN="button_ok"/>
<node CREATED="1312371309768" ID="ID_1839886870" MODIFIED="1312697798141" TEXT="Checkin note">
<arrowlink DESTINATION="ID_848698351" ENDARROW="Default" ENDINCLINATION="374;0;" ID="Arrow_ID_161966745" STARTARROW="None" STARTINCLINATION="374;0;"/>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312371271054" ID="ID_1783086212" MODIFIED="1312697798141" TEXT="Undo checkout">
<arrowlink DESTINATION="ID_848698351" ENDARROW="Default" ENDINCLINATION="326;0;" ID="Arrow_ID_962443310" STARTARROW="None" STARTINCLINATION="326;0;"/>
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1312254205348" ID="ID_832848464" LINK="http://localhost:3000/templates/35/new" MODIFIED="1312697798141" TEXT="New">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312254210163" ID="ID_1907591348" LINK="http://localhost:3000/templates/35/history" MODIFIED="1312697798141" TEXT="History">
<icon BUILTIN="button_ok"/>
<node CREATED="1312371526400" ID="ID_1703966360" MODIFIED="1312697798141" TEXT="Edit">
<arrowlink DESTINATION="ID_1070789323" ENDARROW="Default" ENDINCLINATION="87;0;" ID="Arrow_ID_684565956" STARTARROW="None" STARTINCLINATION="87;0;"/>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312371552309" ID="ID_593831891" MODIFIED="1339312383035" TEXT="Rollback">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312371565929" ID="ID_1366894905" MODIFIED="1312697798142" TEXT="Compare with previous">
<icon BUILTIN="button_ok"/>
<node CREATED="1312372049579" ID="ID_895789219" MODIFIED="1339312396754" TEXT="Compare specific versions">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Compare lijkt niet helemaal lekker te gaan. Met name met baseline version? Dus version 0 met version 1?
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312371726772" ID="ID_1588536183" LINK="http://localhost:3000/versions/59" MODIFIED="1312697798142" TEXT="Versions 3">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312257265185" ID="ID_423712391" LINK="http://localhost:3000/" MODIFIED="1312697798142" TEXT="Home">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312257269996" ID="ID_350250627" LINK="http://localhost:3000/sites/description?id=2" MODIFIED="1312697798142" TEXT="Manage (sites/description)">
<arrowlink DESTINATION="ID_720276126" ENDARROW="Default" ENDINCLINATION="232;0;" ID="Arrow_ID_1704835856" STARTARROW="None" STARTINCLINATION="232;0;"/>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312373351442" ID="ID_598157586" LINK="http://localhost:3000/users/account" MODIFIED="1312697798143" TEXT="onno.van.der.straaten@gmail (users/account)">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node CREATED="1312185847208" ID="ID_637931983" LINK="http://localhost:3000/portal/users" MODIFIED="1339312498277" TEXT="Users">
<icon BUILTIN="button_ok"/>
<node CREATED="1312625389029" ID="ID_1224512118" LINK="http://localhost:3000/users/1" MODIFIED="1312697806162" TEXT="My Public Page">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312185855225" FOLDED="true" ID="ID_1883608991" LINK="http://localhost:3000/sites/list" MODIFIED="1368952447141" TEXT="Manage">
<icon BUILTIN="button_ok"/>
<node CREATED="1312373737605" ID="ID_967679880" MODIFIED="1312697798144" TEXT="">
<node CREATED="1312373739180" ID="ID_1473433287" LINK="http://localhost:3000/sites/new" MODIFIED="1312697798144" TEXT="New Baseline Process">
<icon BUILTIN="button_ok"/>
<node CREATED="1312385848312" ID="ID_462860940" MODIFIED="1312697798144" TEXT="Create from server folder">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312385856089" ID="ID_608728185" MODIFIED="1312697798144" TEXT="Create from upload">
<icon BUILTIN="button_ok"/>
<node CREATED="1339313195142" ID="ID_1902396928" MODIFIED="1339313239057" TEXT="cvs">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1312373747689" ID="ID_1282744355" LINK="http://localhost:3000/sites/new_wiki" MODIFIED="1312697798144" TEXT="New Wiki">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312373670439" ID="ID_808603612" MODIFIED="1312697798145" TEXT="">
<node CREATED="1312373497722" ID="ID_1561214482" LINK="http://localhost:3000/sites/list" MODIFIED="1339315508118" TEXT="Sites">
<icon BUILTIN="button_ok"/>
<node CREATED="1312380476326" ID="ID_1614367741" MODIFIED="1312697798145" TEXT="">
<node CREATED="1312373636153" ID="ID_720276126" LINK="http://localhost:3000/sites/description?id=2" MODIFIED="1312697798145" TEXT="Templates (sites/description)">
<icon BUILTIN="button_ok"/>
<node CREATED="1312463382070" ID="ID_1051494771" MODIFIED="1312697798145" TEXT="Daily etc report of changes">
<icon BUILTIN="stop"/>
</node>
<node CREATED="1312520739072" ID="ID_215554722" LINK="http://localhost:3000/sites/versions/2" MODIFIED="1312697798145" TEXT="Versions">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pagination
    </p>
    <p>
      Filter
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312521550959" ID="ID_923415077" LINK="http://localhost:3000/sites/comments/3" MODIFIED="1312697798146" TEXT="Comments">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pagination
    </p>
    <p>
      Filter
    </p>
    <p>
      Edit
    </p>
    <p>
      Destroy
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
<node CREATED="1339925271363" ID="ID_940898468" MODIFIED="1339925277297" TEXT="Review NOte">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339925288691" ID="ID_858962976" MODIFIED="1339925292595" TEXT="Reviewer">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339925313352" ID="ID_651649134" MODIFIED="1339925365941" TEXT="Review Complete">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339925409136" ID="ID_1971521729" MODIFIED="1339925414235" TEXT="Edit">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339925447113" ID="ID_542854715" MODIFIED="1339925454925" TEXT="Destroy">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312528241018" ID="ID_1392567310" LINK="http://localhost:3000/sites/pages/3" MODIFIED="1312697798146" TEXT="Pages">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Paginate
    </p>
    <p>
      Activate
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312528254768" ID="ID_1919392772" LINK="http://localhost:3000/sites/uploads/3" MODIFIED="1312697798146" TEXT="Uploads">
<icon BUILTIN="button_ok"/>
<node CREATED="1339916206976" ID="ID_890931548" MODIFIED="1339916214920" TEXT="Review Note">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339916298897" ID="ID_200329876" MODIFIED="1339916304398" TEXT="Review Complete">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339916309142" ID="ID_529532964" MODIFIED="1339916411114" TEXT="Edit">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339916311724" ID="ID_1859725821" MODIFIED="1339916413234" TEXT="Destroy">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339916330183" ID="ID_338901657" MODIFIED="1339916339648" TEXT="Reviewer">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339916439741" ID="ID_1626222159" MODIFIED="1339916449128" TEXT="Upload new">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312528268856" ID="ID_1819172456" LINK="http://localhost:3000/sites/feedback?id=3" MODIFIED="1312697798147" TEXT="Feedback">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Paginate
    </p>
    <p>
      Done
    </p>
    <p>
      User
    </p>
    <p>
      Reviewer
    </p>
    <p>
      Review note
    </p>
    <p>
      Edit
    </p>
    <p>
      Destroy
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
<node CREATED="1339908309058" ID="ID_58295756" MODIFIED="1339915150787" TEXT="Review Note">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339908314424" ID="ID_545945152" MODIFIED="1339915153958" TEXT="Destroy">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339909940170" ID="ID_1314204412" MODIFIED="1339915156039" TEXT="Reviewer">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339914500707" ID="ID_1778319865" MODIFIED="1339915158411" TEXT="Done">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1312380500267" ID="ID_963951372" LINK="http://localhost:3000/development_wikis/templates/index.htm" MODIFIED="1312697798147" TEXT="Activate Templates">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312380478731" ID="ID_610718795" LINK="http://localhost:3000/rss/list?site_folder=templates" MODIFIED="1339314290220" TEXT="RSS">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312380528314" ID="ID_901318619" LINK="http://localhost:3000/users/1" MODIFIED="1312697820922" TEXT="onno">
<arrowlink DESTINATION="ID_1224512118" ENDARROW="Default" ENDINCLINATION="294;0;" ID="Arrow_ID_470998747" STARTARROW="None" STARTINCLINATION="294;0;"/>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312380536657" ID="ID_716915477" LINK="http://localhost:3000/sites/description?id=1" MODIFIED="1312699347537" TEXT="&#x9;templates_20080828">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Edit
    </p>
    <p>
      Activate
    </p>
    <p>
      CSV
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312380565674" ID="ID_19909916" LINK="http://localhost:3000/development_sites/templates_20080828/index.htm" MODIFIED="1312697997897" TEXT="Activate Templates 20080828 &gt; Index">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312380592685" ID="ID_1739937253" LINK="http://localhost:3000/sites/csv/1" MODIFIED="1312698007681" TEXT="Download templates_20080828 as CSV">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1339315515727" ID="ID_1298105254" MODIFIED="1339315522047" TEXT="Obsolete">
<icon BUILTIN="button_cancel"/>
<node CREATED="1339315532666" ID="ID_216374512" MODIFIED="1339315532666" TEXT="The action does not allow a GET request, a POST request should be used"/>
</node>
</node>
</node>
<node CREATED="1312373502283" ID="ID_14071437" LINK="http://localhost:3000/users/list" MODIFIED="1312701760825" TEXT="Users">
<icon BUILTIN="button_ok"/>
<node CREATED="1312700551739" ID="ID_731288359" MODIFIED="1312701535001" TEXT="Other user page">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312700618687" ID="ID_381604443" MODIFIED="1312701537457" TEXT="Make user admin">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312700623425" ID="ID_1794861421" MODIFIED="1312701539585" TEXT="Make user cadmin">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312700745546" ID="ID_1207023816" MODIFIED="1312701709727" TEXT="Destroy">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Disabled. Geen link meer om te kunnen verwijderen.
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312373507273" ID="ID_1857310581" LINK="http://localhost:3000/other/about" MODIFIED="1312701757338" TEXT="About">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312373694824" ID="ID_375115289" MODIFIED="1312697798149" TEXT="">
<node CREATED="1312373351442" ID="ID_1176381349" LINK="http://localhost:3000/users/account" MODIFIED="1312697798149" TEXT="onno.van.der.straaten@gmail (users/account)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pagination
    </p>
    <p>
      Filter
    </p>
    <p>
      Edit
    </p>
    <p>
      Destroy not working
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1312257265185" ID="ID_346163315" LINK="http://localhost:3000/" MODIFIED="1312697798149" TEXT="Home">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312373520837" ID="ID_46468673" LINK="http://localhost:3000/login/logout" MODIFIED="1312701780345" TEXT="Logout (login/logout)">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node CREATED="1312185862459" ID="ID_642632418" LINK="http://localhost:3000/portal/about" MODIFIED="1312701791498" TEXT="About">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312389430246" ID="ID_1955861899" MODIFIED="1339819473916" POSITION="right" TEXT="Login">
<icon BUILTIN="button_ok"/>
<node CREATED="1312699455623" ID="ID_1375473849" LINK="http://localhost:3000/login/sign_up" MODIFIED="1312700372842" TEXT="localhost:3000 &gt; Login &gt; Sign up">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Confirm link
    </p>
    <p>
      Sign in
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312700268930" ID="ID_1862443685" MODIFIED="1312700385465" TEXT="Lost password">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Confirm
    </p>
    <p>
      Sign in
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312521263776" ID="ID_370471577" MODIFIED="1312700465334" TEXT="Remember me">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sign in with remember me en restart browser en auto login
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312186788470" ID="ID_827778823" MODIFIED="1312697798151" POSITION="right" TEXT="">
<cloud/>
<node CREATED="1312186673856" ID="ID_133844495" LINK="http://localhost:3000/portal/feedback" MODIFIED="1312697798151" TEXT="Feedback">
<icon BUILTIN="button_ok"/>
<node CREATED="1339906375944" ID="ID_1192295133" MODIFIED="1339906378549" TEXT="Submit"/>
</node>
<node CREATED="1312186680268" ID="ID_790375023" LINK="http://localhost:3000/portal/termsofuse" MODIFIED="1312697798151" TEXT="Terms of Use">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312186685739" ID="ID_284193579" LINK="http://localhost:3000/portal/privacypolicy" MODIFIED="1312697798151" TEXT="Privacy Policy">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312529387235" ID="ID_711437021" MODIFIED="1312701986240" POSITION="right" TEXT="">
<node CREATED="1312529389476" ID="ID_909260525" MODIFIED="1312697798152" TEXT="Create new page ">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312530496917" ID="ID_1878078552" LINK="http://localhost:3000/uploads/new" MODIFIED="1312697798152" TEXT="Upload file">
<icon BUILTIN="button_ok"/>
<node CREATED="1312530522078" ID="ID_1464861094" LINK="http://localhost:3000/uploads/list" MODIFIED="1312697798152" TEXT="List">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Paginate
    </p>
    <p>
      Edit
    </p>
    <p>
      Destroy
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_1878078552" ENDARROW="Default" ENDINCLINATION="101;0;" ID="Arrow_ID_251086298" STARTARROW="None" STARTINCLINATION="101;0;"/>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312529418648" ID="ID_271971353" MODIFIED="1312697798153" TEXT="My Account">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Send change report
    </p>
    <p>
      Edit (changes etc)
    </p>
    <p>
      Remove notification
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_1224512118" ENDARROW="Default" ENDINCLINATION="267;0;" ID="Arrow_ID_570417871" STARTARROW="None" STARTINCLINATION="267;0;"/>
<icon BUILTIN="button_ok"/>
<node CREATED="1312625427160" ID="ID_90672171" LINK="http://localhost:3000/users/admin_message?id=1" MODIFIED="1312697798153" TEXT="Edit admin message">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312529422536" ID="ID_1718174616" MODIFIED="1312697798153" TEXT="EPF Wiki User Guide">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312442381590" ID="ID_1473094994" MODIFIED="1312701992193" POSITION="right" TEXT="Jobs">
<icon BUILTIN="button_ok"/>
<node CREATED="1312442435852" ID="ID_1367551266" MODIFIED="1312697798153" TEXT="rake --tasks">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312442395426" ID="ID_1442032856" MODIFIED="1312697798153" TEXT="rake epfw:update RAILS_ENV=development">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ostraaten@onno-top:~/Workspace/EPFWiki_Rails3_2$ rake epfw:update RAILS_ENV=development
    </p>
    <p>
      (in /home/ostraaten/Workspace/EPFWiki_Rails3_2)
    </p>
    <p>
      Running update in development
    </p>
    <p>
      ostraaten@onno-top:~/Workspace/EPFWiki_Rails3_2$
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312442543959" ID="ID_1838902529" MODIFIED="1312697798153" TEXT="rake epf:update RAILS_ENV=test">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1312521078197" ID="ID_1257246779" MODIFIED="1312701984169" TEXT="Review notes">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1312521327872" ID="ID_513989771" MODIFIED="1312697798154" POSITION="left" TEXT="Cachning"/>
<node CREATED="1312532051825" ID="ID_807904386" MODIFIED="1312697798154" POSITION="left" TEXT="Make obsolete"/>
<node CREATED="1312784032450" ID="ID_546667451" MODIFIED="1312784034947" POSITION="left" TEXT="404"/>
<node CREATED="1339315460826" ID="ID_1215212841" MODIFIED="1339315464316" POSITION="right" TEXT="Harvesting"/>
</node>
</map>
