# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
EPFWikiRails3::Application.config.secret_token = 'f9f94888c1f2740b6dd83c4eaa5f9656083365eea6e1f667a00b6a37c77872b6cb73dc53a97a3dc67e5011e46425aa3d53b8fee79297c7a4bf91d6d6d964eba3'
