# Include hook code here
require 'templates/templates'
require 'fileutils'
