Rake::TaskManager.record_task_metadata=true
#Rake.application.load 'Rakefile'